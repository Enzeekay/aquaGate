Sounds in this folder are made by Filip Hracek and are CC0 (Public Domain).
